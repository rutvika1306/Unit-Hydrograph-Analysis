# -*- coding: utf-8 -*-
"""
Created on Wed Apr  2 12:39:53 2025

@author: rutvi
"""

import numpy as np
import matplotlib.pyplot as plt


#ERH data
time_erh = [0, 0.5, 1, 1.5, 2, 2.5]  #hours
rainfall = [2.5, 6, 8.5, 0, 4.5, 1]  #mm/hr

#DRH data
time_drh = [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5]  #hrs
runoff = [0, 12, 22.5, 33, 42, 42, 35, 28.5, 27, 29, 26.5, 20, 13, 7.5, 5, 3, 1, 0]  #m^3/s

dt = 0.5 * 3600  #hours to seconds

total_runoff_volume = sum(np.array(runoff) * dt)  #sum of Q * dt

total_excess_rainfall = sum(np.array(rainfall) * (dt / 3600))  #sum of P * dt


catchment_area = total_runoff_volume / (total_excess_rainfall * 0.001)  #converting mm to m

print(f"Catchment Area: {catchment_area:.2f} m^2, {catchment_area*10**(-6):.2f} km^2")


P=np.array([[1.25,0,0,0,0,0,0,0,0,0,0],           #excess rainfall matrix
            [3,1.25,0,0,0,0,0,0,0,0,0],
            [4.25,3,1.25,0,0,0,0,0,0,0,0],
            [0,4.25,3,1.25,0,0,0,0,0,0,0],
            [2.25,0,4.25,3,1.25,0,0,0,0,0,0],
            [0.5,2.25,0,4.25,3,1.25,0,0,0,0,0],
            [0,0.5,2.25,0,4.25,3,1.25,0,0,0,0],
            [0,0,0.5,2.25,0,4.25,3,1.25,0,0,0],
            [0,0,0,0.5,2.25,0,4.25,3,1.25,0,0],
            [0,0,0,0,0.5,2.25,0,4.25,3,1.25,0],
            [0,0,0,0,0,0.5,2.25,0,4.25,3,1.25],
            [0,0,0,0,0,0,0.5,2.25,0,4.25,3],
            [0,0,0,0,0,0,0,0.5,2.25,0,4.25],
            [0,0,0,0,0,0,0,0,0.5,2.25,0],
            [0,0,0,0,0,0,0,0,0,0.5,2.25],
            [0,0,0,0,0,0,0,0,0,0,1.5]])

PT=np.transpose(P) #P transpose

PTP=np.dot(PT,P)  #Ptranspose x P

Inv_PTP=np.linalg.inv(PTP)

Q=np.array([[12],[22.5],[33],[42],[42],[35],[28.5],[27],[29],[26.5],[20],[13],[7.5],[5],[3],[1]])

Inv_PTP_PT=np.dot(Inv_PTP,PT)  #inv of Ptranspose and P

U=np.dot(Inv_PTP_PT,Q)    #unit hydrograph ordinates

print("ordinates of unit hydrograph in m³/s per mm ",U)
print("Duration of unit hydrograph is 5 hr")

U=[2.01419888,2.45826056,2.39109532,1.76014933,0.94617569,0.67525181,1.20066927,1.57425731,1.2217519,0.57053703,0.11858847]
time=[0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5]

plt.plot(time,U,label="UH of 0.5hr interval")
plt.legend()
plt.xlabel("Time (hours)")
plt.ylabel("Unit Hydrograph (m³/s per mm)")
plt.title("Unit hydrograph of 0.5 hr interval")
plt.grid()
plt.show()


U = np.array([4.0284,4.4724,4.9165,4.8493,4.7822,4.1512,3.5203,2.7063,1.8923,1.6214,1.3505,1.8759,2.4013,2.7749,3.1485,2.796,2.4435,1.7923,1.1411,0.6891,0.2372])
S1 = np.cumsum(U)  #S-Curve by cumulative sum


#75-min (1.25-hour) unit hydrograph
S1_75=[4.0284 , 8.5008, 13.4173 ,18.2666, 23.0488, 27.2, 30.7203, 33.4266, 35.3189, 36.9403, 38.2908, 40.1667, 42.568,  45.3429, 48.4914 ,51.2874, 53.7309, 55.5232, 56.6643, 57.3534 ,57.5906,57.5906,57.5906,57.5906,57.5906,57.5906]
S2_75=np.array([0,0,0,0,0,4.0284 , 8.5008, 13.4173 ,18.2666, 23.0488, 27.2, 30.7203, 33.4266, 35.3189, 36.9403, 38.2908, 40.1667, 42.568,  45.3429, 48.4914 ,51.2874, 53.7309, 55.5232, 56.6643, 57.3534 ,57.5906])
unit_hydrograph_75min=(S1_75-S2_75)/1.25
print(unit_hydrograph_75min)


#90-min (1.5-hour) unit hydrograph
S1_90=[4.0284 , 8.5008, 13.4173 ,18.2666, 23.0488, 27.2, 30.7203, 33.4266, 35.3189, 36.9403, 38.2908, 40.1667, 42.568,  45.3429, 48.4914 ,51.2874, 53.7309, 55.5232, 56.6643, 57.3534 ,57.5906,57.5906,57.5906,57.5906,57.5906,57.5906,57.5906,57.5906]
S2_90=np.array([0,0,0,0,0,0,0,4.0284 , 8.5008, 13.4173 ,18.2666, 23.0488, 27.2, 30.7203, 33.4266, 35.3189, 36.9403, 38.2908, 40.1667, 42.568,  45.3429, 48.4914 ,51.2874, 53.7309, 55.5232, 56.6643, 57.3534 ,57.5906])
unit_hydrograph_90min=((S1_90-S2_90)/1.5)
print("Ordinates of 90min hydrograph",unit_hydrograph_90min)


time_intervals = np.arange(0, len(unit_hydrograph_75min) * 0.5, 0.5)  
plt.plot(time_intervals, unit_hydrograph_75min, marker='o', linestyle='-', label="75-Min UH")
time_intervals = np.arange(0, len(unit_hydrograph_90min) * 0.5, 0.5)  
plt.plot(time_intervals, unit_hydrograph_90min, marker='o', linestyle='-', label="90-Min UH")


plt.xlabel("Time (hours)")
plt.ylabel("Unit Hydrograph (m³/s per mm)")
plt.title("Unit Hydrographs of Different Durations")
plt.legend()
plt.grid()
plt.show()